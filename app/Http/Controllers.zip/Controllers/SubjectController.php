<?php

namespace App\Http\Controllers;

use App\Models\Exercise;
use App\Models\Lessontype;
use App\Models\Subject;
use App\Http\Requests\StoreSubjectRequest;
use App\Http\Requests\UpdateSubjectRequest;
use App\Models\User;
use App\Models\Faculty;
use App\Models\Group;
use App\Services\LogWriter;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use function PHPUnit\Framework\isNull;

class SubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Application|Factory|View|\Illuminate\Http\Response
     */
    public function index()
    {
        abort_if_forbidden('subject.show');

        $faculties = Faculty::all();
        $users = User::where('id', '!=', auth()->user()->id)->get();
        $subjects = Subject::all();

        return view('pages.subjects.index', compact('users', 'subjects'));
    }


    public function add()
    {
        abort_if_forbidden('subject.create');

        $groups = Group::all();
        return view('pages.subjects.add', compact('groups'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        abort_if_forbidden('subject.create');

        $this->validate($request, [
            'subject_name' => ['required'],
        ]);

        $subject = Subject::create([
            'subject_name' => $request->get('subject_name'),
        ]);

        foreach ($request->groups_id as $g) {
            DB::table('subject_has_group')->insert([
                'groups_id'     => $g,
                'subjects_id'   => $subject->id
            ]);
        }

        return redirect()->route('subjectIndex');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreSubjectRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSubjectRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param Subject $subject
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $id = $request->input('id');
        $exercises = Exercise::where('subjects_id',$id)->select('id','title','lessontypes_id','teachers_id','subjects_id')->get();

        $exercises = Exercise::where('subjects_id', '=', $id)
            ->select('exercises.id', 'exercises.title','exercises.subjects_id', 'lessontypes.id as lessontypes_id', 'lessontypes.name', 'teachers.id as teachers_id', 'teachers.fullname as fullname')
            ->join('lessontypes', 'exercises.lessontypes_id', '=', 'lessontypes.id')
            ->join('teachers', 'exercises.teachers_id', '=', 'teachers.id')
            ->get();

        return response()->json($exercises);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param $id
     * @return Application|Factory|View
     */
    public function edit($id)
    {
        abort_if_forbidden('subject.edit');

        $groups = Group::all();
        $subject = Subject::findOrFail($id);

        return view('pages.subjects.edit', compact('subject', 'groups'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateSubjectRequest  $request
     * @param Subject $subject
     * @return RedirectResponse
     */
    public function update(Request $request, $id)
    {
        abort_if_forbidden('subject.edit');

        $subject = Subject::find($id);
        $subject->fill($request->all());
        $subject->update([
            'subject_name' => $request->subject_name,
        ]);

        DB::table('subject_has_group')
            ->where('subjects_id','=',$id)
            ->delete();

        if($request->groups_id){
            foreach ($request->groups_id as $g) {
                DB::table('subject_has_group')->insert([
                    'groups_id'     => $g,
                    'subjects_id'   => $id
                ]);
            }
        }

        return redirect()->route('subjectIndex');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Subject $subject
     * @return RedirectResponse
     */
    public function deleteAll(Request $request)
    {

        $ids = $request->ids;

        
        $res = subject::whereIn('id',$ids)->delete();
        if($res){
            return response()->json([
                'success'=>true,
                "message" => "This action successfully complated"
            ]); 
        }
        return response()->json([
            'success'=>false,
            "message" => "This delete action failed!"
        ]);
    }

    public function destroy(int $id): RedirectResponse
    {
        Subject::find($id)->delete();
        return redirect()->back();
    }
}
