@extends('layouts.admin')
@section('content')
    <livewire:questions />
@endsection
