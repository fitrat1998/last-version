@extends('layouts.admin')
@section('content')
    <livewire:attendance-lesson/>
@endsection